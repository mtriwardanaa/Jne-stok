<?php

return [
    'name' => 'Supplier'
];
