<?php

return [
    'name' => 'BarangMasuk'
];
