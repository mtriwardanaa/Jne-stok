<?php

return [
    'name' => 'BarangKeluar'
];
