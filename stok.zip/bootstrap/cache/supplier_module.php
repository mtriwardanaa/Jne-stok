<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Supplier\\Providers\\SupplierServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Supplier\\Providers\\SupplierServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);