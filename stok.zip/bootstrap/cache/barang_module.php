<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Barang\\Providers\\BarangServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Barang\\Providers\\BarangServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);