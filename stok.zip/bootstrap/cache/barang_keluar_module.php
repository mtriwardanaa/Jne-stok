<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\BarangKeluar\\Providers\\BarangKeluarServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\BarangKeluar\\Providers\\BarangKeluarServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);