<?php

return [
    'name' => 'Barang'
];
